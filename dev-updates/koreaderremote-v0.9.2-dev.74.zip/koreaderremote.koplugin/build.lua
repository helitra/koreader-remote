return {
    channel = "dev",
    source = "dev",
    version = "0.9.2",
    release_version = "0.9.2-dev.74",
    build_id = "dev.74",
    commit = "fedadfd460e683c658a4f3d53cc2611312146e27",
}
